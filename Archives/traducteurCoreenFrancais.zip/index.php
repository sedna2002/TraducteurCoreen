<?php
    include "Methodes_Connexions.php";

    session_start();

    //ConnexionRedirectionAdmin();
    ConnexionUser_Detail();
    if (ConnexionUser() == UserStatut::NonConnecte)
    {
        // pas de cache pour cette page
        header("Location: Connexion.php"); 
        //header("Cache-Control: no-cache, must-revalidate"); 
        exit;
    }
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html id="htmlMain" lang="fr">

    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <meta http-equiv="Access-Control-Allow-Origin" content="*" />
        <meta http-equiv="Access-Control-Allow-Methods" content="GET, POST, PUT, DELETE" />
        <meta http-equiv="Access-Control-Expose-Headers" content="*" />
        <link rel="icon" type="image/jpeg" href="image/logo.jpeg" />
        <!--<link rel="stylesheet" type="text/css" href="css/Report_Grafana.css" media="all" />-->
        <link rel="stylesheet" type="text/css" href="index.css" media="all" />
        <title>Traducteur Francais <===> Coréen</title>
    </head>

    <body id="bodyMain" ng-app="myApp">

        <h1>Vocabulaire Coréen</h1>

        <select id="voiceSelect" style="display: none;"></select>
        <br/>
        <table id="themes">
            <!--<caption>Themes</caption>-->
            <tbody>
            <!--
                <tr>
                    <td><button type="button" style = "background-color: #691eca;" >ANIMAUX</button></td>
                </tr>
            -->
            </tbody>
        </table>

        <table id="apprentissage" style="display: none" >
            <!--<caption>Apprentissage</caption>-->
            <tbody>
                <tr>
                    <td colspan="2" ><button id="mot_coreen" class="c_mot_coreen" type="button"></button></td>
                </tr>
                <tr>
                    <td colspan="2" class="c_mot_francais" id="mot_francais" ></td>
                </tr>
                <tr>
                    <td><button type="button" style="background-color: #2c87ff;" id="mot_retour" >RETOUR</button></td>
                    <td><button type="button" style="background-color: #2c87ff;" id="mot_suivant" >SUIVANT</button></td>
                </tr>
            </tbody>
        </table>

        <table id="testCoreen1" style="display: none" >
            <!--<caption>Test de mots coréen</caption>-->
            <tbody>
                <tr>
                    <td colspan="2" style="text-align: center;"><button  class="c_mot_coreen" id="mot_coreen" type="button"></button></td>
                </tr>
                <tr>
                    <td><button type="button" class="button_testCoreen1" id="mot_francais_0" >?</button></td>
                    <td><button type="button" class="button_testCoreen1" id="mot_francais_1" >?</button></td>
                </tr>
                <tr>
                    <td><button type="button" class="button_testCoreen1" id="mot_francais_2" >?</button></td>
                    <td><button type="button" class="button_testCoreen1" id="mot_francais_3" >?</button></td>
                </tr>
            </tbody>
        </table>

        <table id="dictionnaire" style="display: none" >
            <thead>
                <tr>
                    <!--<th>Theme</th>-->
                    <th>Sous theme</th>
                    <th>Fancais</th>
                    <th>Coréen</th>
                    <th>Vu</th>
                </tr>
            </thead>
            <tbody style="overflow-y: auto;">

            </tbody>
        </table>

        <br/>
        <table id="menu">
            <tbody>
                <tr>
                    <td>
                        <button type="button" id="dictionnaire" >Dictionnaire</button>
                    </td>
                    <td>
                        <button type="button" id="lancer" >Lancer le test</button>
                        <button type="button" id="arreter" style="display: none" >Arrêter le test</button>
                    </td>
                </tr>
            </tbody>
        </table>

    </body>
    <!--<script src="dictionnaire.js"></script>-->
    <!--<script src="https://code.jquery.com/jquery-3.6.0.js" ></script>-->
    <script src="jquery-3.6.0.js"></script>
    <script src="index.js"></script>
</html>