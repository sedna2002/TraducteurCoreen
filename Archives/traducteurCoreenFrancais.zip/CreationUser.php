<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
        <title>Creation d'un Utilisateur</title>
</head>

<body>

<style type="text/css">

table  {
border-width:0px; 
border-style:solid; 
border-color:black;
/* width:80%; */
border-collapse: collapse; 
text-align:center;
margin:auto;
font-size:14;
/* display:; */
}

</style>

<form id="form1">
<?php

include "Methodes_Connexions.php";
session_start();

?>

<h2 style="text-align:center;"><?php echo ( ConnexionUser() == UserStatut::NonConnecte ? 'Creation d\'un Utilisateur' : 'Mise à jour de votre compte' ) ; ?></h2><br/>

<br/>
<br/>
<?php


$User_id = -1;
$Nom = null;
$Prenom = null;
$Mail1 = null;
$Mail2 = null;
$mail1Enable = false;
$mail2Enable = false;
$Administrateur = false;
$Login = null;
$Password = null;
$Valider = false;
$Telephone = null;
$loginServiceSMSFree = null;
$clefServiceSMSFree = null;
$KeyAPI = null;
$SecretAPI = null;
$ServiceSMSFreeEnable = false;

if ( ConnexionUser() != UserStatut::NonConnecte )
{
    $User_id = $_SESSION['Connexion_User']['User_id'];
    $Nom = $_SESSION['Connexion_User']['Nom'];
    $Prenom = $_SESSION['Connexion_User']['Prenom'];
    $Mail1 = $_SESSION['Connexion_User']['Mail1'];
    $Mail2 = $_SESSION['Connexion_User']['Mail2'];
    $mail1Enable = $_SESSION['Connexion_User']['mail1Enable'];
    $mail2Enable = $_SESSION['Connexion_User']['mail2Enable'];
    $Administrateur = $_SESSION['Connexion_User']['Administrateur'];
    $Login = $_SESSION['Connexion_User']['Login'];
    $Password = $_SESSION['Connexion_User']['Password'];
    $Valider = $_SESSION['Connexion_User']['Valider'];
    $Telephone = $_SESSION['Connexion_User']['Telephone'];
    $loginServiceSMSFree = $_SESSION['Connexion_User']['loginServiceSMSFree'];
    $clefServiceSMSFree = $_SESSION['Connexion_User']['clefServiceSMSFree'];
    $KeyAPI = $_SESSION['Connexion_User']['KeyAPI'];
    $SecretAPI = $_SESSION['Connexion_User']['SecretAPI'];
    $ServiceSMSFreeEnable = $_SESSION['Connexion_User']['ServiceSMSFreeEnable'];
}

ConnexionUser_Detail();

?>
<br/>
<br/>
<table>

    <tr <?php echo (ConnexionUser() != UserStatut::NonConnecte ? 'style="display:none;"' : '' ); ?> >
        <td style="text-align:right;" ><span>Login</span></td>
        <td style="text-align:left;" ><input type="text" id="login" value="<?php echo $Login; ?>" />*</td>
    </tr>
    <tr <?php echo (ConnexionUser() != UserStatut::NonConnecte ? 'style="display:none;"' : '' ); ?> >
        <td style="text-align:right;" ><span>Mot de passe</span></td>
        <td style="text-align:left;" ><input type="password" id="PW" onchange="confirmPW()" />*<input type="checkbox" onchange="PW_afficher()" id="PW_afficher_id" />Afficher les mots de passe</td>
    </tr>
    <tr <?php echo (ConnexionUser() != UserStatut::NonConnecte ? 'style="display:none;"' : '' ); ?> >
        <td style="text-align:right;" ><span>Confirmer le mot de passe</span></td>
        <td style="text-align:left;" ><input type="password" id="PW_confirme" onchange="confirmPW()" />*<span id="PW_correspondent" ></span></td>
    </tr>

    <tr>
        <td style="text-align:right;" ><span>Prenom</span></td>
        <td style="text-align:left;" ><input type="text" id="prenom" value="<?php echo $Prenom; ?>" />*</td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>Nom</span></td>
        <td style="text-align:left;" ><input type="text" id="nom" value="<?php echo $Nom; ?>" />*</td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>E-mail 1</span></td>
        <td style="text-align:left;" ><input type="text" id="mail1" value="<?php echo $Mail1; ?>" /><input type="checkbox" id="mail1_check" <?php echo ($mail1Enable ? "checked" : ""); ?> /><input type="button" value="Envoyer un mail de test" style="background:#FF000080" onclick="send_mail('mail1')" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>E-mail 2</span></td>
        <td style="text-align:left;" ><input type="text" id="mail2" value="<?php echo $Mail2; ?>" /><input type="checkbox" id="mail2_check" <?php echo ($mail2Enable ? "checked" : ""); ?> /><input type="button" value="Envoyer un mail de test" style="background:#FF000080" onclick="send_mail('mail2')" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>Telephone (SMS free)</span></td>
        <td style="text-align:left;" ><input type="text" id="telephone" value="<?php echo $Telephone; ?>" /><input type="checkbox" id="telephone_check" <?php echo ($ServiceSMSFreeEnable ? "checked" : ""); ?> /><input type="button" value="Envoyer un SMS de test" style="background:#FF000080" onclick="send_mail('SMS')" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>login service (SMS free)</span></td>
        <td style="text-align:left;" ><input type="text" id="telephone_login" value="<?php echo $loginServiceSMSFree; ?>" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>PW service (SMS free)</span></td>
        <td style="text-align:left;" ><input type="text" id="telephone_pw" value="<?php echo $clefServiceSMSFree; ?>" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>Key API</span></td>
        <td style="text-align:left;" ><input type="text" id="key_api" value="<?php echo $KeyAPI; ?>" /></td>
    </tr>
    <tr>
        <td style="text-align:right;" ><span>Secret API</span></td>
        <td style="text-align:left;" ><input type="text" id="secret_api" value="<?php echo $SecretAPI; ?>" /></td>
    </tr>

</table>
<br/>
<span>* = Champ obligatoire</span>
<br/>
<br/>
<div style="text-align:center;" >
<input type="button" style="background:#FF800080" value="<?php echo (ConnexionUser() == UserStatut::NonConnecte ? 'Créer mon compte' : 'Mettre à jour mon compte'); ?>" onclick="creationCompte(<?php echo (ConnexionUser() == UserStatut::NonConnecte ? true : false); ?>)" />
</div>

<?php




?>

</form>

<script type="text/javascript" src="md5.js"></script>
<script type="text/javascript" src="XHR.js"></script>
<script type="text/javascript" >

function PW_afficher()
{
    var o = document.getElementById('PW_afficher_id').checked;
    document.getElementById('PW').type = o ? "text" : "password";
    document.getElementById('PW_confirme').type = o ? "text" : "password";
}

function confirmPW()
{
    var pw = document.getElementById('PW').value;
    var pw_conf = document.getElementById('PW_confirme').value;

    if (pw.length < 3)
        {
            document.getElementById('PW').style.background = "#FF000080";
            return 1;
        }

    if (pw_conf.length < 3)
        {
            document.getElementById('PW_confirme').style.background = "#FF000080";
            return 1;
        }

    if ( pw_conf != pw )
        {
            document.getElementById('PW').style.background = "#FF800080";
            document.getElementById('PW_confirme').style.background = "#FF800080";
            document.getElementById('PW_correspondent').innerHTML = "Les mots de passe ne correspondent pas.";
            return 2;
        }

    document.getElementById('PW').style.background = "#00FF0080";
    document.getElementById('PW_confirme').style.background = "#00FF0080";
    document.getElementById('PW_correspondent').innerHTML = "";

    return 0;
}

function creationCompte(create)
{
    var pw_conf = document.getElementById('PW_confirme').value;
    var pw = document.getElementById('PW').value;

    if (create)
    {
        var pw_verif = confirmPW();
        if (pw_verif != 0)
        {
            switch (pw_verif)
            {
                case 1: alert("Le mot de passe ne respecte pas les conditions"); break;
                case 2: alert("Les mots de passe ne correspondent pas"); break;
            }
            
            return;
        }
    }

    var login = document.getElementById('login').value;
    var pw_md5 = hex_md5(pw);

    var nom = document.getElementById('nom').value;
    var prenom = document.getElementById('prenom').value;
    var mail1 = document.getElementById('mail1').value;
    var mail2 = document.getElementById('mail2').value;
    var telephone = document.getElementById('telephone').value;
    var telephone_login = document.getElementById('telephone_login').value;
    var telephone_pw = document.getElementById('telephone_pw').value;
    var telephone_check = document.getElementById('telephone_check').checked;
    var mail1_check = document.getElementById('mail1_check').checked;
    var mail2_check = document.getElementById('mail2_check').checked;
    var key_api = document.getElementById('key_api').value;
    var secret_api = document.getElementById('secret_api').value;

    if (nom.length < 2)
        { document.getElementById('nom').style.background = "#FF000080"; return; }

    if (prenom.length < 2)
        { document.getElementById('prenom').style.background = "#FF000080"; return; }

    document.getElementById('nom').style.background = "";
    document.getElementById('prenom').style.background = "";

    var xhr = getXMLHttpRequest();
    var url = "CreationUser_Verification.php"+(!create ? "?update=1" : "");
    xhr.open("POST", url , true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.addEventListener('readystatechange', function() {
    if (xhr.readyState == 4 && xhr.status >= 200 ) //|| xhr.status == 0 ))
            {
                connect_rep = xhr.responseText;
                
                if (connect_rep == "OK")
                {
                        if (create) 
                            window.location.reload();
                            else
                            alert("Les modifications ont été prises en compte");
                }
                else
                alert(connect_rep);
            }
    });

    xhr.send("login="+login+"&pw="+pw_md5+"&nom="+nom+"&prenom="+prenom+"&mail1="+mail1+"&mail2="+mail2+"&telephone="+telephone+ 
        "&telephone_login="+telephone_login+"&telephone_pw="+telephone_pw+"&telephone_check="+telephone_check+"&key_api="+key_api+"&secret_api="+secret_api+ 
        "&mail1_check="+mail1_check+"&mail2_check="+mail2_check);
}

function send_mail(mailSMS)
{
    var xhr = getXMLHttpRequest();
    var url = "SendMail.php";
    xhr.open("POST", url , true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.addEventListener('readystatechange', function() {
        if (xhr.readyState == 4)
        {
            if (xhr.status == 204 || xhr.status == 200) //|| xhr.status == 0 ))
                {      
                    connect_rep = xhr.responseText;
                    
                    alert("Test effectué OK"+"\n\r"+connect_rep);
                }
                else
                    alert("Test effectué KO !!!");
        }     
    });

    xhr.send("mail="+mailSMS);
}


</script>

</body>

</html>