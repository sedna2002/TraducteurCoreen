Init();
async function Init() {

    //document.body.style.zoom="150%";
    var couleursTheme = [ "ff7300" , "da2c97" , "691eca" , "18b0d6", "1fc082" , "70d81b" ];

    function SpeechCFG(volume, rate, voiceId, voiceX)
    {
        this.Volume = volume;
        this.Rate = rate;
        this.Voice = undefined;

        SpeechCFG.prototype.SelectVoice = function(voiceId, voiceX)
        {
            var voices = speechSynthesis.getVoices();
            var voice = voices.find(v => v.lang == voiceId && (voiceX != undefined ? v.name.includes(voiceX) : true));
            this.Voice = voice;

            return voice;
        }

        if (voiceId != undefined)
            this.SelectVoice(voiceId, voiceX);


        SpeechCFG.prototype.Talk = async function(text, f_end, ...params)
        {
            if (this.Voice == undefined)
                return;

            var utterThis = new SpeechSynthesisUtterance(text);
            utterThis.rate = this.Rate;
            utterThis.volume = this.Volume;
            utterThis.voice = this.Voice;
            speechSynthesis.speak(utterThis);
            if (f_end != undefined)
            {
                utterThis.addEventListener('end', function(event) {
                    Object.apply(this, f_end(event, ...params));
                });
            }
        }
    }

    var voiceFR;
    var voiceKR;
    setTimeout(() => {
        voiceFR = new SpeechCFG(1, 0.9, "fr-FR", "Julie");
        voiceKR = new SpeechCFG(1, 0.9, "ko-KR", "한국의");
    }, 1000);

    var testStarted = false;
    var dictionnaire = new Array();
    var apprentissage = new Array();
    var apprentissageEtapeN = 0;
    var dictionnaireCSV;

    var headers = new Headers();
    headers.append("Accept", "text/plain");
    var optionsFetch = { method: 'GET',
               headers: headers,
               mode: 'cors',
               cache: 'default' };
    await fetch('dictionnaire.csv', optionsFetch)
        .then( function(response) {
            //return response.blob();
            return response.text();
        })
        .then( function (response) {
            dictionnaireCSV = response;
        });

    // parser CSV
    var lines = dictionnaireCSV.split('\r\n');
    var colonnes = lines[0].split(';');
    var index_theme = colonnes.findIndex(e => e == 'theme');
    var index_sous_theme = colonnes.findIndex(e => e == 'sous-theme');
    var index_coreen = colonnes.findIndex(e => e == 'coreen');
    var index_francais = colonnes.findIndex(e => e == 'francais');

    for(var i = 1;i < lines.length;i++)
    {
        var line = lines[i].split(';');

        try
        {
        var themeNom = line[index_theme].nomPropre();
        var sous_themeNom = line[index_sous_theme].nomPropre();
        }
        catch(e)
        { }
        var coreen = line[index_coreen];
        var francais = line[index_francais]

        var theme = dictionnaire.find(e => e.theme == themeNom && e.sous_theme == sous_themeNom);
        if (theme == undefined)
        {
            theme = { theme: themeNom, sous_theme: sous_themeNom, liste: new Array() };
            dictionnaire.push(theme);
        }

        theme.liste.push({ coreen : coreen , francais : francais , image: "" });
    }

    // creation des boutons de themes
    var table = document.getElementById('themes');
    var tbody = table.getElementsByTagName('tbody')[0];
    var themes = dictionnaire.reduce((a, e) => {
        if (!a.includes(e.theme))
            a.push(e.theme);

        return a;
    }, new Array() );

    for(var i = 0;i < themes.length;i++)
    {
        var tr = document.createElement('tr');
        tr.className = "tr_theme";
        var td = document.createElement('td');
        var button = document.createElement('button');
        button.type = "button";
        button.className = "theme";
        button.style.backgroundColor = couleursTheme[i % 6];
        button.innerHTML = themes[i];
        button.tag = { theme : themes[i] };
        td.appendChild(button);
        tr.appendChild(td);
        tbody.appendChild(tr);
    }

    var trs = tbody.getElementsByTagName('tr');
    for(var i = 0;i < themes.length;i++)
    {
        var sous_themes = dictionnaire.reduce((a, e) => {
            if (e.theme == themes[i] && !a.includes(e.sous_theme))
                a.push(e.sous_theme);
    
            return a;
        }, new Array() );

        for(var j = 0;j < sous_themes.length;j++)
        {
            var tr = trs[i];
            var td = document.createElement('td');
            var button = document.createElement('button');
            button.type = "button";
            button.className = "sous_theme";
            button.style.backgroundColor = couleursTheme[i % 6];
            button.innerHTML = sous_themes[j]; // + "   [" + sous_themes[j].length + "]";
            button.tag = { theme : themes[i] , sous_theme : sous_themes[j] };
            td.appendChild(button);
            tr.appendChild(td);
        }
    }

    var table = document.getElementById('themes');
    var bs = table.querySelectorAll("tbody tr td button");
    Array.from(bs).forEach((b, i) => {
        b.addEventListener('click', function() { selectionTheme(this); });
    });

    var button_suivant = document.getElementById('mot_suivant');
    button_suivant.addEventListener('click', function() {
        apprentissageEtapeN++;
        
        if (apprentissageEtapeN == apprentissage.length)
        {
            //demarrage du test
            tablesAllInvisible();

            testCoreen1();
        }
        else
            apprentissageEtape(apprentissageEtapeN);
    });
    var button_retour = document.getElementById('mot_retour');
    button_retour.addEventListener('click', function() {
        apprentissageEtapeN--;
        if (apprentissageEtapeN < 0)
            apprentissageEtapeN = 0;

        apprentissageEtape(apprentissageEtapeN);
    });

    var b_dictionnaire = document.querySelector('button#dictionnaire');
    b_dictionnaire.addEventListener('click', function() {

        tablesAllInvisible();
        var table = document.querySelector('table#dictionnaire');
        table.style.display = "";

        tbody = table.querySelector('tbody');
        tbody.innerHTML = "";

        var themeNom_old = "";
        var themeNom_I = 0;
        for(var i = 1;i < lines.length;i++)
        {
            var line = lines[i].split(';');
    
            try
            {
            var themeNom = line[index_theme].nomPropre();
            var sous_themeNom = line[index_sous_theme].nomPropre();
            }
            catch(e)
            { }
            var coreen = line[index_coreen];
            var francais = line[index_francais]

            var tr = document.createElement('tr');
            if (themeNom_old != themeNom)
            {
                themeNom_old = themeNom;
                themeNom_I++;

                var td = document.createElement('td');
                td.innerHTML = themeNom;
                td.style.backgroundColor = couleursTheme[themeNom_I % 6];
                td.setAttribute('theme', true);
                tr.setAttribute('theme', true);
                tr.appendChild(td);
                
            }
            else
            {
                var td = document.createElement('td');
                td.innerHTML = sous_themeNom;
                td.setAttribute('theme', false);
                tr.appendChild(td);
                var td = document.createElement('td');
                td.innerHTML = francais;
                td.setAttribute('theme', false);
                tr.appendChild(td);
                var td = document.createElement('td');
                td.innerHTML = coreen;
                td.setAttribute('theme', false);
                tr.appendChild(td);
                var td = document.createElement('td');
                td.innerHTML = 0;
                td.setAttribute('theme', false);
                tr.setAttribute('theme', false);
                tr.appendChild(td);
            }
            tr.addEventListener('click', async function() {
                var tr = this;
                var tds = tr.getElementsByTagName('td');
                var td = tds[2];

                tr.setAttribute('talk', false); // true

                tr.style.backgroundColor = "green";
                await voiceKR.Talk(td.innerHTML , (ev, This) => {
                    This.setAttribute('talk', false);
                    tr.style.backgroundColor = "";
                }, button);
        
            });
            tbody.appendChild(tr);

        }

        // Change the selector if needed
        var $table = $('table#dictionnaire'),
            $bodyCells = $table.find('tbody tr[theme=false]:first').children(),
            colWidth;

        // Get the tbody columns width array
        colWidth = $bodyCells.map(function() {
        return $(this).width();
        }).get();

        // Set the width of thead columns
        $table.find('thead tr').children().each(function(i, v) {
        $(v).width(colWidth[i]);
        });  

    });

    var b_arreter = document.getElementById('arreter');
    b_arreter.addEventListener('click', function() {

        tablesAllInvisible();
        var table = document.getElementById('themes');
        table.style.display = "";
        var select = document.getElementById('voiceSelect');
        select.style.display = "";
        testStarted = false;
        var b_lancer = document.getElementById('lancer');
        b_lancer.style.display = "";

        this.style.display = "none";
    });

    var b_lancer = document.getElementById('lancer');
    b_lancer.addEventListener('click', function() {

        tablesAllInvisible();

        var table = document.getElementById('themes');
        var buttons = table.querySelectorAll('button.sous_theme[selected="true"]');

        if (buttons.length == 0)
        {
            alert("Veuillez selectionner un/des theme(s) ou sous_theme(s) ");
            testStarted = false;
            table.style.display = "";
            return;
        }

        testStarted = true;

        this.style.display = "none";
        var b_arreter = document.getElementById('arreter');
        b_arreter.style.display = "";

        var table = document.getElementById('apprentissage');
        table.style.display = "";
        apprentissage = new Array();
        var apprentissageX = new Array();

        for(var i = 0;i < buttons.length;i++)
        {
            var theme = dictionnaire.find(t => t.theme == buttons[i].tag.theme && t.sous_theme == buttons[i].tag.sous_theme );
            apprentissageX = apprentissageX.concat(theme.liste);
        }
        
        var N = C(4, apprentissageX.length);
        for(var j = 0;j < 4;j++)
        {
            apprentissage.push(Object.assign(apprentissageX[N[j]], { success : 0 }));
        }

        apprentissageEtapeN = 0;
        apprentissageEtape(apprentissageEtapeN);

    });

    var buttons = document.querySelectorAll('#mot_coreen');
    Array.from(buttons).forEach(b => {
        b.addEventListener('click', function() {

            this.setAttribute('talk', false); // true
            voiceKR.Talk(this.innerText , (ev, This) => {
                This.setAttribute('talk', false);
            }, this);

        });
    });

    async function testCoreen1()
    {
        var table = document.getElementById('testCoreen1');
        table.style.display = "";

        var button = table.querySelector('#mot_coreen');
        var n = Math.floor(Math.random() * apprentissage.length);
        button.innerHTML = apprentissage[ n ].coreen;
        button.tag = apprentissage[ n ];

        button.setAttribute('talk', false); // true
        await voiceKR.Talk(apprentissage[n].coreen , (ev, This) => {
            This.setAttribute('talk', false);
        }, button);

        motFrancaisTestCoreen1();
    }
    
    async function apprentissageEtape(n)
    {
        var table = document.getElementById('apprentissage');
        var button = table.querySelector('#mot_coreen');
        var tdF = table.querySelector('#mot_francais');
        button.innerHTML = apprentissage[n].coreen;
        tdF.innerHTML = apprentissage[n].francais;

        button.setAttribute('talk', false); // true
        await voiceKR.Talk(apprentissage[n].coreen , (ev, This) => {
            This.setAttribute('talk', false);
        }, button);
        await voiceFR.Talk(apprentissage[n].francais);
    }

    function motFrancaisTestCoreen1()
    {
        var table = document.getElementById('testCoreen1');
        var N = C(4, 4);
        for(var i = 0;i < 4;i++)
        {
            var button = table.querySelector('#mot_francais_' + i);
            button.style.backgroundColor = "#2c87ff";
            button.innerHTML = apprentissage[N[i]].francais + ( apprentissage[N[i]].success > 0 ? " [" + apprentissage[N[i]].success + "]" : "");
            button.tag = apprentissage[N[i]];
            button.onclick = function() {
                var buttonK = table.querySelector('#mot_coreen');

                var p = apprentissage.find(e => e.francais == buttonK.tag.francais );
                //var p = apprentissage.find(e => e.francais == this.tag.francais );

                if (this.tag.francais == buttonK.tag.francais)
                {
                    p.success++;
                    this.style.backgroundColor = "green";

                    setTimeout(() => {
                        testCoreen1();
                    }, 1000);

                }
                else
                {
                    p.success = 0;
                    this.style.backgroundColor = "red";

                    var buttons = table.querySelectorAll('.button_testCoreen1');
                    var buttonX = Array.from(buttons).find(b => b.tag.francais == buttonK.tag.francais );
                    buttonX.style.backgroundColor = "green";

                    setTimeout(() => {
                        testCoreen1();
                    }, 2000);
                }

            };
        }
    }

    function populateVoiceList() {
        if(typeof speechSynthesis === 'undefined') {
            return;
        }
        
        var voices = speechSynthesis.getVoices();
        
        for(var i = 0; i < voices.length; i++) {
            var option = document.createElement('option');
            option.textContent = voices[i].name + ' (' + voices[i].lang + ')';
            option.tag = voices[i];
        
            if(voices[i].default) {
            option.textContent += ' -- DEFAULT';
            }
        
            option.setAttribute('data-lang', voices[i].lang);
            option.setAttribute('data-name', voices[i].name);
            document.getElementById("voiceSelect").appendChild(option);
        }
    }
    
    populateVoiceList();
    if (typeof speechSynthesis !== 'undefined') {
            speechSynthesis.addEventListener('voiceschanged', populateVoiceList);
    }
    document.getElementById("voiceSelect").addEventListener('change', function() {
        var utterThis = new SpeechSynthesisUtterance(this.value);
        var voice = this.selectedOptions[0].tag; // getAttribute('data-name');
        voiceSelected = voice;
        utterThis.voice = voice;
        speechSynthesis.speak(utterThis);
    });

    function selectionTheme(This)
    {
        if (This.tag == undefined)
        {
            This.tag = { selected: false };
        }

        This.tag.selected = !This.tag.selected;
        if (This.className == "theme")
        {
            var tr = This.parentElement.parentElement;
            var buttons = tr.getElementsByTagName('button');
            Array.from(buttons).forEach((e, i) => {
                e.setAttribute('selected', This.tag.selected);
            });
        }
        else
            This.setAttribute('selected', This.tag.selected);
    }

    function tablesAllInvisible()
    {
        var tables = document.getElementsByTagName('table');
        Array.from(tables).forEach(t => { t.style.display = "none"; })

        var select = document.getElementById('voiceSelect');
        select.style.display = "none";
    }

    function C(n,p)
    {
        var N = new Array();
        var M = new Array();

        for(var i = 0;i < p;i++) { N.push(i); }
        for(var i = 0;i < n;i++) 
        { 
            var x = Math.floor(Math.random() * N.length);
            M.push(N[x]);
            N.splice(x, 1);
        }

        return M;
    }
}

String.prototype.nomPropre = function()
{
    if (this.length == 0)
        return this;
    try
    {
        var M = this.substring(0, 1).toUpperCase();
        return M + (this.length > 1 ? this.substring(1, this.length ).toLowerCase() : "");
    }
    catch(e)
    {
        console.log(e);
    }
}